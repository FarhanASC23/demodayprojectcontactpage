let btn = document.getElementById('submitbtn')

btn.addEventListener('click', function(e) {
  e.default
})